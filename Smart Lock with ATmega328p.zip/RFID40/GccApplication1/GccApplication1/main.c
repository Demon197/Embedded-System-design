
#include <avr/io.h>
#include <util/delay.h>
#include <lcd.h>
#include <spi.h>
#include <mfrc522.h>
#include <Keypad.h>

#define BUZZER PB0
#define RELAY PB1
#define GREEN PB6
#define RED PB7
#define EEPROM_START_ADDRESS 0x80

#define NO1 	2
#define NO2 	3

void gate_action();
void relay();
void beep_buzzer();
void green_led();
void red_led();

void relay(){
	PORTB |= (1 << RELAY);
	_delay_ms(500);
	PORTB &= ~(1 << RELAY);
}

void beep_buzzer() {
	PORTB |= (1 << BUZZER);
	_delay_ms(100);
	PORTB &= ~(1 << BUZZER);
}

void green_led() {
	PORTB |= (1 << GREEN);
	_delay_ms(500);
	PORTB &= ~(1 << GREEN);
}

void red_led() {
	PORTB |= (1 << RED);
	_delay_ms(1000);
	PORTB &= ~(1 << RED);
}

void gate_action()
{
	lcd_print("Xin Chao");
	relay();
	beep_buzzer();
	green_led();
	_delay_ms(4000);
}




int main()
{
	uint8_t byte;
	uint8_t str[MAX_LEN];
	uint8_t person_recognised = 0;
	uint8_t Number1[4]  ={0xF4,0x18,0xCE,0xCF};
	uint8_t Number2[4] ={0xE3,0x10,0x7D,0x00};
	
	_delay_ms(50);
	lcd_init();
	lcd_print("RFID");
	
	spi_init();
	mfrc522_init();
	_delay_ms(1500);
	lcd_clear();
	
	byte = mfrc522_read(VersionReg);
	if(byte == 0x92)
	{
		lcd_print("Xin Chao");
	}else if(byte == 0x91 || byte==0x90)
	{
		lcd_print("GROUP 17");
		
	}else
	{
		lcd_print("No reader");
	}
	
	_delay_ms(1500);
	lcd_clear();
	
	while(1){
		lcd_clear();
		lcd_print("RFID Card");
		byte = mfrc522_request(PICC_REQALL,str);
		
		if(byte == CARD_FOUND)
		{
			byte = mfrc522_get_card_serial(str);
			if(byte == CARD_FOUND)
			{
				person_recognised = 1;
				for(byte=0;byte<4;byte++)
				{
					if(Number1[byte] != str[byte])
						break;
				}
				if(byte == 4)
					person_recognised = NO1;
				else
				{
					for(byte=0;byte<4;byte++)
					{
						if(Number2[byte] != str[byte])
							break;
					}
					if(byte == 4)
						person_recognised = NO2;
				}
				switch(person_recognised)
				{
					case NO1 : 
					{
						lcd_clear();
						lcd_print("Group 17");						
						gate_action();
						
						break;
					}
					case NO2 : 
					{
						lcd_clear();
						lcd_print("Nhom 17");
						gate_action();
						
						break;
					}
					default :
					{
						lcd_clear();
						lcd_print("Not RFID !");
						
						break;
					}
				}
			}
			else
			{
				
				lcd_clear();
				lcd_print("Error");
				
			}
		}
	}
}

