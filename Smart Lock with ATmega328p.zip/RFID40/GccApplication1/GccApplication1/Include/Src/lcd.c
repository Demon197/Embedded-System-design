/*
 * lcd.c
 *
 * Created: 07/12/2024 7:04:11 CH
 *  Author: hoang
 */ 

#include <avr/io.h>
#include <util/delay.h>

#include <lcd.h>

//Custom Charset support


void lcd_command(unsigned char cmd) {
	LCD_PORT = (LCD_PORT & 0xC3) | ((cmd & 0xF0) >> 2);
	LCD_PORT &= ~(1 << LCD_RS);
	LCD_PORT |= (1 << LCD_E);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_E);
	_delay_us(100);
	LCD_PORT = (LCD_PORT & 0xC3) | ((cmd << 2) & 0x3C);
	LCD_PORT |= (1 << LCD_E);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_E);
	_delay_ms(2);
}

void lcd_data(unsigned char data) {
	LCD_PORT = (LCD_PORT & 0xC3) | ((data & 0xF0) >> 2);
	LCD_PORT |= (1 << LCD_RS);
	LCD_PORT |= (1 << LCD_E);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_E);

	LCD_PORT = (LCD_PORT & 0xC3) | ((data << 2) & 0x3C);
	LCD_PORT |= (1 << LCD_E);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_E);
	_delay_ms(2);
}

void lcd_init(void) {
	LCD_DDR |= 0xFF;
	_delay_ms(20);

	lcd_command(0x02);
	lcd_command(0x28);
	lcd_command(0x0C);
	lcd_command(0x06);
	lcd_command(0x01);
	_delay_ms(2);
}

void lcd_clear() {
	lcd_command(0x01);
	_delay_ms(2);
}

void lcd_print(const char *str) {
	while (*str) {
		lcd_data(*str++);
	}
}