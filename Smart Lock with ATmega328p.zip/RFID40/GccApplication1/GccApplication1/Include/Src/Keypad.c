#include <lcd.h>
#include <Keypad.h>

const char key_map[4][3] = {
	{'1', '2', '3'},
	{'4', '5', '6'},
	{'7', '8', '9'},
	{'*', '0', '#'}
};

char read_keypad() {
	for (uint8_t col = 0; col < 3; col++) {
		COLUMN_PORT |= (1 << PD0) | (1 << PD1) | (1 << PD2);
		COLUMN_PORT &= ~(1 << (PD0 + col));
		_delay_ms(5);

		for (uint8_t row = 0; row < 4; row++) {
			if (!(ROW_PIN & (1 << (PD4 + row)))) {
				_delay_ms(20);
				if (!(ROW_PIN & (1 << (PD4 + row)))) {
					while (!(ROW_PIN & (1 << (PD4 + row))));
					return key_map[row][col];
				}
			}
		}
	}
	return 0;
}

