/*
 * Keypad.h
 *
 * Created: 11/12/2024 9:34:20 SA
 *  Author: hoang
 */ 


#ifndef KEYPAD_H_
#define KEYPAD_H_

#define COLUMN_PORT PORTD
#define COLUMN_DDR DDRD
#define ROW_PIN PIND
#define ROW_PORT PORTD



#endif /* KEYPAD_H_ */