/*
 * lcd.h
 *
 * Created: 07/12/2024 6:53:00 CH
 *  Author: hoang
 */ 


#include <avr/io.h>

#include <util/delay.h>


#ifndef _LCD_H
#define _LCD_H

#define LCD_DDR DDRC
#define LCD_PORT PORTC
#define LCD_RS PC0
#define LCD_E PC1


/*_________________________________________________________________________________________*/
#endif
