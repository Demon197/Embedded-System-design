#define F_CPU 1000000UL
#include <avr/io.h>
#include <avr/eeprom.h>
#include <util/delay.h>

// Dinh nghia chan
#define BUZZER PB0
#define RELAY PB1
#define GREEN PB6
#define RED PB7

// Ket noi LCD
#define LCD_DDR DDRC
#define LCD_PORT PORTC
#define LCD_RS PC0
#define LCD_E PC1

// Ket noi ban phim
#define COLUMN_PORT PORTD
#define COLUMN_DDR DDRD
#define ROW_PIN PIND
#define ROW_PORT PORTD

// Ban do ky tu ban phim
const char key_map[4][3] = {
	{'1', '2', '3'},
	{'4', '5', '6'},
	{'7', '8', '9'},
	{'*', '0', '#'}
};

// Dia chi EEPROM bat dau
#define EEPROM_START_ADDRESS 0x80

// Ghi mat khau vao EEPROM tai dia chi 0x80
void write_password(const char *password) {
	for (uint8_t i = 0; i < 4; i++) {
		eeprom_write_byte((uint8_t *)(EEPROM_START_ADDRESS + i), password[i]); // Ghi so (dang uint8_t)
	}
}

// Doc mat khau tu EEPROM tai dia chi 0x80
void read_password(char* password) {
	for (uint8_t i = 0; i < 4; i++) {
		password[i] = eeprom_read_byte((uint8_t *)(EEPROM_START_ADDRESS + i));
	}
	password[4] = '\0'; // Ket thuc chuoi
}

// Kiem tra mat khau
uint8_t check_password(char *input_password) {
	char stored_password[5];
	read_password(stored_password); // Doc mat khau tu EEPROM

	// So sanh
	for (uint8_t i = 0; i < 4; i++) {
		if (input_password[i] != stored_password[i]) {
			return 0; // Sai mat khau
		}
	}
	return 1; // Mat khau dung
}

// Cac ham dieu khien LCD
void lcd_command(unsigned char cmd) {
	LCD_PORT = (LCD_PORT & 0xC3) | ((cmd & 0xF0) >> 2);
	LCD_PORT &= ~(1 << LCD_RS);
	LCD_PORT |= (1 << LCD_E);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_E);
	_delay_us(100);
	LCD_PORT = (LCD_PORT & 0xC3) | ((cmd << 2) & 0x3C);
	LCD_PORT |= (1 << LCD_E);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_E);
	_delay_ms(2);
}

void lcd_data(unsigned char data) {
	LCD_PORT = (LCD_PORT & 0xC3) | ((data & 0xF0) >> 2);
	LCD_PORT |= (1 << LCD_RS);
	LCD_PORT |= (1 << LCD_E);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_E);

	LCD_PORT = (LCD_PORT & 0xC3) | ((data << 2) & 0x3C);
	LCD_PORT |= (1 << LCD_E);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_E);
	_delay_ms(2);
}

void lcd_init(void) {
	LCD_DDR |= 0xFF;
	_delay_ms(20);

	lcd_command(0x02);
	lcd_command(0x28);
	lcd_command(0x0C);
	lcd_command(0x06);
	lcd_command(0x01);
	_delay_ms(2);
}
void relay(){
	PORTB |= (1 << RELAY);
	_delay_ms(500);
	PORTB &= ~(1 << RELAY);
}

void lcd_clear() {
	lcd_command(0x01);
	_delay_ms(2);
}

void lcd_print(const char *str) {
	while (*str) {
		lcd_data(*str++);
	}
}

// Ham doc ky tu tu ban phim
char read_keypad() {
	for (uint8_t col = 0; col < 3; col++) {
		COLUMN_PORT |= (1 << PD0) | (1 << PD1) | (1 << PD2);
		COLUMN_PORT &= ~(1 << (PD0 + col));
		_delay_ms(5);

		for (uint8_t row = 0; row < 4; row++) {
			if (!(ROW_PIN & (1 << (PD4 + row)))) {
				_delay_ms(20);
				if (!(ROW_PIN & (1 << (PD4 + row)))) {
					while (!(ROW_PIN & (1 << (PD4 + row))));
					return key_map[row][col];
				}
			}
		}
	}
	return 0;
}

// Cac chuc nang bao hieu
void beep_buzzer() {
	PORTB |= (1 << BUZZER);
	_delay_ms(3000);
	PORTB &= ~(1 << BUZZER);
}

void green_led() {
	PORTB |= (1 << GREEN);
	_delay_ms(500);
	PORTB &= ~(1 << GREEN);
}

void red_led() {
	PORTB |= (1 << RED);
	_delay_ms(1000);
	PORTB &= ~(1 << RED);
}
// Chuc nang doi mat khau
void doi_mat_khau() {
	int sai = 0;
	char key;
	char old_password[5] = "";
	char new_password[5] = "";
	uint8_t index = 0;
	uint8_t clear_screen = 0;
	uint8_t mode = 0;
	lcd_clear();
	lcd_print("Doi mat khau");
	_delay_ms(1000);
	lcd_clear();
	lcd_print("Nhap mat khau cu");
	while (1) {
		key = read_keypad();
		_delay_us(200);
		if (key) {
			if (clear_screen == 0) {
				lcd_clear();
				clear_screen = 1;
			}
			if (mode == 0) {
				if (index < 4) {
					old_password[index++] = key;
					old_password[index] = '\0';
					lcd_data('*');
				}
				if (index == 4) {
					index = 0;
					lcd_clear();
					if (check_password(old_password)) {
						lcd_print("Mat khau dung");
						_delay_ms(1000);
						lcd_clear();
						lcd_print("Nhap matkhau moi");
						mode = 1;
						clear_screen = 0;
						} else {
						lcd_print("Sai mat khau");
						_delay_ms(1000);
						sai++;
						if (sai == 2) {
							lcd_clear();
							lcd_print("Thoat");
							_delay_ms(2000);
							return;
						}
						lcd_clear();
						lcd_print("Nhap lai mat khau cu");
						clear_screen = 0;
					}
				}
				} else if (mode == 1) {
				if (index < 4) {
					new_password[index++] = key;
					new_password[index] = '\0';
					lcd_data('*');
				}

				if (index == 4) {
					lcd_clear();
					lcd_print("Cap nhat mat khau");
					write_password(new_password);
					_delay_ms(1000);
					lcd_clear();
					lcd_print("Hoan thanh");
					_delay_ms(2000);
					return;
				}
			}
		}
	}
}


// Chuc nang nhap mat khau
void nmk() {
	
	
	int sai = 0;
	char key;
	uint8_t password_mode = 0;
	uint8_t clear_screen = 0;
	char password[5] = "";
	uint8_t index = 0;
	laplai : lcd_init();
	lcd_print(" nhap mk : *");
	lcd_command(0xC0);
	lcd_print("  doi mk : #");
	while (1) {
		key = read_keypad();
		_delay_us(200);

		if (key) {
			if (key == '*') {
				lcd_clear();
				lcd_print("Nhap mat khau");
				password_mode = 1;
				clear_screen = 0;
				index = 0;
				} else if (key == '#') {
				doi_mat_khau(); // Goi ham doi mat khau
				lcd_clear();
				beep_buzzer();
				green_led();
				goto laplai;
				
				} else if (password_mode) {
				if (clear_screen == 0) {
					lcd_clear();
					clear_screen = 1;
				}

				if (index < 4) {
					password[index++] = key;
					password[index] = '\0'; // Ket thuc chuoi
					lcd_data('*');
				}

				if (index == 4) {
					password_mode = 0;
					lcd_clear();
					_delay_ms(500);
					if (check_password(password)) {
						lcd_print("Dung mat khau");
						beep_buzzer();
						green_led();
						relay();
						} else {
						lcd_print("Sai mat khau");
						red_led();
						sai++;
						if (sai == 3) {
							lcd_clear();
							lcd_print("Cho 30s...");
							_delay_ms(30000);
							sai = 0;
						}
					}
					_delay_ms(1000);
					lcd_clear();
					goto laplai;
				}
				} else {
				lcd_clear();
				lcd_print(" nhan 0 return mn ");
				if (key == '0') {
					lcd_clear();
					goto laplai ;
				}
			}
		}
	}
}

int main() {
	COLUMN_DDR |= (1 << PD0) | (1 << PD1) | (1 << PD2);
	COLUMN_PORT |= (1 << PD0) | (1 << PD1) | (1 << PD2);

	DDRD &= ~((1 << PD4) | (1 << PD5) | (1 << PD6) | (1 << PD7));
	ROW_PORT |= (1 << PD4) | (1 << PD5) | (1 << PD6) | (1 << PD7);

	DDRB |= (1 << BUZZER) | (1 << GREEN) | (1 << RED);


	// Ghi mat khau mac dinh vao EEPROM
	char default_password[] = {'1', '2', '3', '4'};
	write_password(default_password);

	nmk();

}
